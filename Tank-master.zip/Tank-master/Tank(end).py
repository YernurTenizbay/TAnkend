import pygame
import math
from math import *
pygame.init()
window = pygame.display.set_mode((800,600))
soundbullet=pygame.mixer.Sound("battle-city-sfx-6.wav")
soundbody=pygame.mixer.Sound("move.wav")
soundrote=pygame.mixer.Sound("rotate.wav")
soundbody.set_volume(0.3)
Font = pygame.font.SysFont("Times New Roman", 20)
rad = pi/180
score=1
class Tank():
    def __init__(self):
        self.hp=3
        self.x = 200
        self.y = 200
        self.size = 64
        self.speed = 5
        # һself.body = pygame.Surface((self.size,self.size))
        self.body = pygame.image.load("tankbody2.png")
        # self.body.set_colorkey((0,0,0))
        # self.body.fill((0,255,0))
        self.rect = self.body.get_rect()
        self.angle = 0
        self.vel=100
        self.circle = self.body.copy()
        self.circle.set_colorkey((0,255,0))
        self.gun=pygame.image.load("tankb5.png")
        self.gun_r=self.gun.get_rect()
        self.gun_r.center=(0,0)
        self.anglegun=180
        self.direct=True
        self.keep_move=False
        self.zaderzhka = 0
    def move(self,k,sec):
        self.speed=self.vel*sec
        #Keep moving
        if k[pygame.K_n]:
            self.keep_move = True
        elif k[pygame.K_m]:
            self.keep_move = False
        if k[pygame.K_w]:
            self.direct=True
            if not(self.keep_move):
                self.x += self.speed * cos(self.angle*rad)
                self.y -= self.speed * sin(self.angle*rad) 
            if self.x>800:
                self.x=0
            elif self.x<0:
                self.x=800
            if self.y>600:
                self.y=0
            elif self.y<0:
                self.y=600
            pygame.mixer.Sound.play(soundbody)
        elif k[pygame.K_s]:
            self.direct=False
            if not(self.keep_move):           
                self.x -= self.speed * cos(self.angle*rad)
                self.y += self.speed * sin(self.angle*rad)
            if self.x>800:
                self.x=0
            elif self.x<0:
                self.x=800
            if self.y>600:
                self.y=0
            elif self.y<0:
                self.y=600
            pygame.mixer.Sound.play(soundbody)
        if self.keep_move:
            if self.direct==True:
                self.x+= self.speed * cos(self.angle*rad)
                self.y -= self.speed * sin(self.angle*rad)
            if self.direct==False:
                self.x -= self.speed * cos(self.angle*rad)
                self.y += self.speed * sin(self.angle*rad)
            if self.x>800:
                self.x=0
            elif self.x<0:
                self.x=800
            if self.y>600:
                self.y=0
            elif self.y<0:
                self.y=600
        if k[pygame.K_SPACE] and (pygame.time.get_ticks() - self.zaderzhka)/1000 >=1:
            bullets.append(Bullet(self.x,self.y,self.anglegun,"tank1"))
            pygame.mixer.Sound.play(soundbullet)
            self.zaderzhka = pygame.time.get_ticks()
            

        self.rect.center = (self.x,self.y)
        self.gun_r.center= (self.x-self.size/2,self.y)
        self.collision()
    def rotate(self,k):
        if k[pygame.K_a]:
            self.angle +=1
            self.anglegun+=1
            pygame.mixer.Sound.play(soundbody)
        elif k[pygame.K_d]:
            self.angle -=1
            self.anglegun-=1
            pygame.mixer.Sound.play(soundbody)
        if k[pygame.K_q]:
            self.anglegun +=1
            pygame.mixer.Sound.play(soundrote)
        elif k[pygame.K_e]:
            self.anglegun -=1
            pygame.mixer.Sound.play(soundrote)
        self.angle%=360
        
    def draw(self):
        old_center = self.rect.center
        old_guncenter=self.gun_r.center
        new = pygame.transform.rotate(self.body, self.angle)
        new1=pygame.transform.rotate(self.gun,self.anglegun)
        self.rect = new.get_rect()
        self.gun_r=new1.get_rect()
        self.rect.center = old_center
        self.gun_r.center=old_center
        
        # self.gun_r.center = (old_center[0]+10,old_center[1]+10)ы
        window.blit(new, self.rect)
        window.blit(new1,self.gun_r)
        
        # pygame.draw.circle(self.circle, (0,0,255),(5,5), 5)
        # window.blit(self.circle, (self.x-5,self.y-5)
    def collision(self):
        for f in bullets:
            if self.rect.colliderect(f.rect) and f.boss != "tank1":
                self.hp-=1
                bullets.remove(f)

class Tank2():
    def __init__(self):
        self.x = 400
        self.y = 400
        self.hp=3
        self.size = 64
        self.vel=100
        self.speed = 5
        self.direct=True
        # һself.body = pygame.Surface((self.size,self.size))
        self.body = pygame.image.load("tankbodyenemy2.png")
        # self.body.set_colorkey((0,0,0))
        # self.body.fill((0,255,0))
        self.rect = self.body.get_rect()
        self.angle = 0
        self.circle = self.body.copy()
        self.circle.set_colorkey((0,255,0))
        self.gun=pygame.image.load("tankbenemy5.png")
        self.gun_r=self.gun.get_rect()
        self.gun_r.center=(0,0)
        self.anglegun=180
        self.keep_move=False
        self.zaderzhka = 0
    def move(self,k,sec):
        self.speed=self.vel*sec
        #Keep moving
        if k[pygame.K_KP4]:
            self.keep_move = True
        elif k[pygame.K_KP6]:
            self.keep_move = False
        if k[pygame.K_UP]:
            self.direct=True
            if not(self.keep_move):
                self.x += self.speed * cos(self.angle*rad)
                self.y -= self.speed * sin(self.angle*rad) 
            if self.x>800:
                self.x=0
            elif self.x<0:
                self.x=800
            if self.y>600:
                self.y=0
            elif self.y<0:
                self.y=600
            pygame.mixer.Sound.play(soundbody)
        elif k[pygame.K_DOWN]:
            self.direct=False
            if not(self.keep_move):           
                self.x -= self.speed * cos(self.angle*rad)
                self.y += self.speed * sin(self.angle*rad)
            if self.x>800:
                self.x=0
            elif self.x<0:
                self.x=800
            if self.y>600:
                self.y=0
            elif self.y<0:
                self.y=600
            pygame.mixer.Sound.play(soundbody)
        if self.keep_move:
            if self.direct==True:
                self.x+= self.speed * cos(self.angle*rad)
                self.y -= self.speed * sin(self.angle*rad)
            if self.direct==False:
                self.x -= self.speed * cos(self.angle*rad)
                self.y += self.speed * sin(self.angle*rad)
            if self.x>800:
                self.x=0
            elif self.x<0:
                self.x=800
            if self.y>600:
                self.y=0
            elif self.y<0:
                self.y=600
        if k[pygame.K_RETURN] and (pygame.time.get_ticks() - self.zaderzhka)/1000 >=1:
            bullets.append(Bullet(tank2.x,tank2.y,tank2.anglegun,"tank2"))
            pygame.mixer.Sound.play(soundbullet)
            self.zaderzhka = pygame.time.get_ticks()
            
        self.rect.center = (self.x,self.y)
        self.gun_r.center= (self.x-self.size/2,self.y)
        self.collision()
    def rotate(self,k):
        if k[pygame.K_LEFT]:
            self.angle +=1
            self.anglegun+=1
            pygame.mixer.Sound.play(soundbody)
            pygame.mixer.music.stop()
        elif k[pygame.K_RIGHT]:
            self.angle -=1
            self.anglegun-=1
            pygame.mixer.Sound.play(soundbody)
            pygame.mixer.music.stop()
        if k[pygame.K_KP1]:
            self.anglegun+=1
            pygame.mixer.Sound.play(soundrote)
            pygame.mixer.music.stop()
        elif k[pygame.K_KP3]:
            self.anglegun-=1
            pygame.mixer.Sound.play(soundrote)
            pygame.mixer.music.stop()
        self.angle%=360
    def draw(self):
        old_center = self.rect.center
        old_guncenter=self.gun_r.center
        new = pygame.transform.rotate(self.body, self.angle)
        new1=pygame.transform.rotate(self.gun,self.anglegun)
        self.rect = new.get_rect()
        self.gun_r=new1.get_rect()
        self.rect.center = old_center
        self.gun_r.center=old_center
        # self.gun_r.center = (old_center[0]+10,old_center[1]+10)ы
        window.blit(new, self.rect)
        window.blit(new1,self.gun_r)
    def collision(self):
        for f in bullets:
            if self.rect.colliderect(f.rect) and f.boss != "tank2":
                self.hp-=1
                bullets.remove(f)
class Bullet():
    def __init__(self,x,y,angle,boss):
        self.angle = angle
        self.x = x -24*cos(self.angle*rad)
        self.y = y +24*sin(self.angle*rad)
        self.speed = 20
        self.size = 5
        self.boss = boss
        #self.bullet = pygame.Surface((25,25))
        #self.bullet.set_colorkey((0,0,0))
        #self.bullet.fill((255,0,0))
        self.bullet = pygame.image.load("bullet2.png")
        self.rect = self.bullet.get_rect()
        self.remove = 0

    def move(self):
        self.x -=self.speed * cos(self.angle*rad)
        self.y +=self.speed * sin(self.angle*rad)
        if self.x >=800 or self.y >=600 or self.x<=0 or self.y<=0:
            self.remove = 1
        self.rect.center = (self.x,self.y)

    def draw(self):
        old_center = self.rect.center
        new = pygame.transform.rotate(self.bullet, self.angle + 90)
        self.rect = new.get_rect()
        self.rect.center = old_center
        window.blit(new, self.rect)
bullets = []
tank = Tank()
tank2=Tank2()
fps = pygame.time.Clock()
mil=fps.tick(30)
sec=mil/1000
run = 1
u = 0
l=0
while run:
    for f in pygame.event.get():
        if f.type == pygame.QUIT:
            run = 0
    k = pygame.key.get_pressed()
    window.fill((155,155,155))
    tank.move(k,sec)
    tank2.move(k,sec)
    tank.rotate(k)
    tank2.rotate(k)
    tank.draw()
    tank2.draw()
    window.blit(Font.render(f"Hp:{tank2.hp}",1,(0,255,0)),(0,0))
    window.blit(Font.render(f"Hp:{tank.hp}",1,(255,0,0)),(760,0))
    if tank.hp<=0:
        exit()
    if tank2.hp<=0:
        exit()
    for f in bullets:
        f.move()
        f.draw()

        if f.remove:
            bullets.remove(f)
            u-=1
    pygame.display.update()
    fps.tick(30)
pygame.quit()